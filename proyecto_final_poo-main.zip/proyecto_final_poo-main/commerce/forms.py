from django import forms
from commerce.models import Invoice, Purchase
from core.models import Supplier

class InvoiceForm(forms.ModelForm):
    class Meta:
        model=Invoice
        fields = ['customer', 'payment_method', 'issue_date', 'subtotal', 'iva', 'total']
        widgets = {
            'customer': forms.Select(),
            'payment_method': forms.Select(),
            'issue_date': forms.DateInput(attrs={'type': 'date'}),
            'subtotal': forms.NumberInput(),
            'iva': forms.NumberInput(),
            'total': forms.NumberInput(),
           
        }
        
class PurchaseForm(forms.ModelForm):
    # Hacemos que el campo 'supplier' sea un desplegable
    # con los proveedores que ya creaste.
    supplier = forms.ModelChoiceField(
        queryset=Supplier.objects.filter(state=True),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    class Meta:
        model = Purchase
        # Estos son los campos de la cabecera de la compra
        fields = ['supplier', 'num_document', 'issue_date', 'subtotal', 'iva', 'total']
        widgets = {
            'num_document': forms.TextInput(attrs={'class': 'form-control'}),
            
            # ¡Aquí aplicamos la fecha automática (Fecha y Hora)!
            'issue_date': forms.DateInput(attrs={'type': 'date'}),
            
            # Hacemos los totales 'readonly' porque los calculará el JS
            'subtotal': forms.NumberInput(attrs={'readonly': True}),
            'iva': forms.NumberInput(attrs={'readonly': True}),
            'total': forms.NumberInput(attrs={'readonly': True}),
        }