from django.contrib.auth.mixins import LoginRequiredMixin
from core.mixins import TitleContextMixin
from core.utils import custom_serializer
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView, DetailView, View, DeleteView
from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal
from django.db import transaction
from django.template.loader import render_to_string
import json
from .models import Invoice, InvoiceDetail, Purchase, PurchaseDetail
from .forms import InvoiceForm, PurchaseForm
from core.models import Product, Supplier

class InvoiceListView(LoginRequiredMixin,TitleContextMixin,ListView): 
    model = Invoice 
    template_name = 'invoice/list.html'  # Nombre del template a usar 
    context_object_name = 'invoices'     # Nombre del contexto a pasar al template 
    paginate_by = 10   
                
    title1 = "Autor | TeacherCode"
    title2 = "Listado de Ventas"

    def get_queryset(self):
        # Se Puede personalizar el queryset aquí si es necesario
        queryset = super().get_queryset()  # self.model.objects.all()
        query = self.request.GET.get('q','')
        if query:
            queryset = queryset.filter(Q(customer__last_name__icontains=query) | Q(customer__first_name__icontains=query))
        return queryset
    
   
class InvoiceCreateView(LoginRequiredMixin,TitleContextMixin,CreateView):
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice/form.html"
    success_url = reverse_lazy("commerce:invoice_list")  # Redirigir a la lista de proveedores después de crear uno nuevo
    title1 = '"Ventas"'
    title2 = 'Crear Nueva Venta'
          
    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['products'] = Product.active_products.only('id','description','price','stock','iva')
        context['detail_sales'] =[]
        context['save_url'] = reverse_lazy('commerce:invoice_create') 
        context['invoice_list_url'] = self.success_url 
        print(context['products'])
        return context
    
    def post(self, request, *args, **kwargs):
        print("POST request received")
        print("===== 1. DATOS RECIBIDOS (REQUEST.POST) =====")
        print(request.POST)
        form = self.get_form()
        print("respuest: ",request.POST)
        if not form.is_valid():
            print("===== 2. EL FORMULARIO NO ES VÁLIDO =====")
            print(form.errors)
            messages.success(self.request, f"Error al grabar la venta!!!: {form.errors}.")
            return JsonResponse({"msg":form.errors},status=400)
        data = request.POST
        try:
            with transaction.atomic():
                sale = Invoice.objects.create(
                    customer_id=int(data['customer']),
                    user=request.user,
                    payment_method=data['payment_method'],
                    issue_date=data['issue_date'],
                    subtotal=Decimal(data['subtotal']),
                    iva= Decimal(data['iva']),
                    total=Decimal(data['total'])
                  
                   
                )
                details = json.loads(request.POST['detail'])
                print(details) #[{'id':'1','price':'2'},{}]
                for detail in details:
                    inv_det = InvoiceDetail.objects.create(
                        invoice=sale,
                        product_id=int(detail['id']),
                        quantity=Decimal(detail['quantify']),
                        price=Decimal(detail['price']),
                        iva=Decimal(detail['iva']),  
                        subtotal=Decimal(detail['sub'])
                    )
                    inv_det.product.reduce_stock(Decimal(detail['quantify']))
               
                messages.success(self.request, f"Éxito al registrar la venta F#{sale.id}")
                return JsonResponse({"msg":"Éxito al registrar la venta Factura"},status=200)
        except Exception as ex:
              return JsonResponse({"msg":ex},status=400)
    
class InvoiceUpdateView(LoginRequiredMixin,TitleContextMixin,UpdateView):
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice/form.html"
    success_url = reverse_lazy("commerce:invoice_list")  # Redirigir a la lista de proveedores después de crear uno nuevo
    title1 = '"Venta"'
    title2 = 'Editar Venta'
   
    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['products'] = Product.active_products.only('id','description','price','stock','iva')
        context['invoice_list_url'] = self.success_url 
        detail_sale =list(InvoiceDetail.objects.filter(invoice_id=self.object.id).values(
             "product","product__description","quantity","price","subtotal","iva"))
        print("detalle")
        detail_sale=json.dumps(detail_sale,default=custom_serializer)
        context['detail_sales']=detail_sale  #[{'id':1,'precio':2},{},{}]
        context['save_url'] = reverse_lazy('commerce:invoice_update',kwargs={"pk":self.object.id})
        print(detail_sale)
        return context
    
    def post(self, request, *args, **kwargs):
        print("POST request update")
        form = self.get_form()
        print(request.POST)
        if not form.is_valid():
            messages.success(self.request, f"Error al actualizar la venta!!!: {form.errors}.")
            return JsonResponse({"msg":form.errors},status=400)
        data = request.POST
        try:
            print("facturaId: ")
            print(self.kwargs.get('pk'))
            sale= Invoice.objects.get(id=self.kwargs.get('pk'))
           
            with transaction.atomic():
                sale.customer_id=int(data['customer'])
                sale.user=request.user
                sale.payment_method=data['payment_method']
                sale.issue_date=data['issue_date']
                sale.subtotal=Decimal(data['subtotal'])
                sale.iva= Decimal(data['iva'])
                sale.total=Decimal(data['total'])
                sale.save()

                details = json.loads(request.POST['detail'])
                print(details)
                detdelete=InvoiceDetail.objects.filter(invoice_id=sale.id)
                for det in detdelete:
                    det.product.stock+= int(det.quantity)
                    det.product.save()
                detdelete.delete()
               
                for detail in details:
                    inv_det = InvoiceDetail.objects.create(
                        invoice=sale,
                        product_id=int(detail['id']),
                        quantity=Decimal(detail['quantify']),
                        price=Decimal(detail['price']),
                        iva=Decimal(detail['iva']),  
                        subtotal=Decimal(detail['sub'])
                    )
                    inv_det.product.reduce_stock(Decimal(detail['quantify']))
                messages.success(self.request, f"Éxito al Modificar la venta F#{sale.id}")
                return JsonResponse({"msg":"Éxito al Modificar la venta Factura"},status=200)
        except Exception as ex:
              return JsonResponse({"msg":ex},status=400)


class InvoiceDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Invoice
    template_name = 'invoice/detail_modal.html'
    context_object_name = 'invoice'

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        context = self.get_context_data(object=self.object)
        context['details'] = InvoiceDetail.objects.filter(invoice=self.object)
        html = render_to_string(self.template_name, context, request=request)
        return JsonResponse({'html': html})

class InvoiceDeleteView(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        try:
            with transaction.atomic():
                invoice = Invoice.objects.get(pk=pk)

                # Devolver stock de productos
                details = InvoiceDetail.objects.filter(invoice=invoice)
                for d in details:
                    d.product.stock += d.quantity
                    d.product.save()
                details.delete()

                invoice.delete()
                return JsonResponse({'msg': f'✅ Factura N°{pk} eliminada correctamente.'}, status=200)
        except Invoice.DoesNotExist:
            return JsonResponse({'msg': '⚠️ Factura no encontrada.'}, status=404)
        except Exception as ex:
            return JsonResponse({'msg': f'❌ Error al eliminar: {ex}'}, status=400)


class InvoiceAnnulView(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        try:
            with transaction.atomic():
                invoice = Invoice.objects.get(pk=pk)
                if not invoice.state:
                    return JsonResponse({'msg': '⚠️ La factura ya está anulada.'}, status=400)

                # Revertir stock
                details = InvoiceDetail.objects.filter(invoice=invoice)
                for d in details:
                    d.product.stock += d.quantity
                    d.product.save()

                invoice.state = False
                invoice.save(update_fields=['state'])

                return JsonResponse({'msg': f'🚫 Factura N°{pk} anulada correctamente.'}, status=200)
        except Invoice.DoesNotExist:
            return JsonResponse({'msg': '⚠️ Factura no encontrada.'}, status=404)
        except Exception as ex:
            return JsonResponse({'msg': f'❌ Error al anular: {ex}'}, status=400)
        
        
class PurchaseListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Purchase
    template_name = 'purchase/list.html'
    context_object_name = 'purchases'
    paginate_by = 10
    title1 = "Compras"
    title2 = "Listado de Compras"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            # Buscador por N° de documento o nombre de proveedor
            queryset = queryset.filter(Q(num_document__icontains=query) | Q(supplier__name__icontains=query))
        # Optimizamos la consulta para no hacer N+1 queries
        return queryset.select_related('supplier') 

class PurchaseDeleteView(LoginRequiredMixin, View):
    
    # Esta vista no usa un template, solo responde a POST
    def post(self, request, pk, *args, **kwargs):
        try:
            # Usamos 'transaction.atomic' para proteger la BD
            with transaction.atomic():
                # 1. Obtenemos la compra
                purchase = Purchase.objects.get(pk=pk)
                
                if not purchase.active:
                    return JsonResponse({'msg': '⚠️ La compra ya está anulada.'}, status=400)

                # 2. Obtenemos los detalles de esa compra
                details = PurchaseDetail.objects.filter(purchase=purchase)
                
                # 3. Recorremos los detalles para revertir el stock
                for d in details:
                    # ¡RESTAMOS EL STOCK!
                    if d.quantify > d.product.stock:
                        # Si no hay suficiente stock para restar (porque ya se vendió)
                        # ¡Cancelamos la anulación!
                        raise Exception(f"No se puede anular: Stock insuficiente para '{d.product.description}'.")
                    
                    d.product.stock -= d.quantify
                    d.product.save()

                # 4. Si todo el stock se pudo restar, anulamos la compra
                purchase.active = False
                purchase.save(update_fields=['active'])

                messages.success(request, f"Compra N°{pk} anulada y stock revertido.")
                return JsonResponse({'msg': f'🚫 Compra N°{pk} anulada correctamente.'}, status=200)
        
        except Purchase.DoesNotExist:
            return JsonResponse({'msg': '⚠️ Compra no encontrada.'}, status=404)
        except Exception as ex:
            # Capturamos el error de "stock insuficiente"
            messages.error(request, str(ex))
            return JsonResponse({'msg': f'❌ Error al anular: {ex}'}, status=400)
    
class PurchaseCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Purchase
    form_class = PurchaseForm
    template_name = "purchase/form.html"
    success_url = reverse_lazy("commerce:purchase_list")
    title1 = "Compras"
    title2 = "Nueva Compra"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Pasamos los productos al template (para el <select>)
        context["products"] = Product.objects.filter(state=True) 
        # Pasamos las URLs que necesitará el JavaScript
        context["save_url"] = reverse_lazy("commerce:purchase_create")
        context["purchase_list_url"] = self.success_url
        return context

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        try:
            # Usamos 'with transaction.atomic()' para proteger la BD
            with transaction.atomic():
                if form.is_valid():
                    # Obtenemos los detalles (productos) del JavaScript
                    details = json.loads(request.POST['detail'])
                    if not details:
                        messages.error(request, "No se puede guardar una compra vacía.")
                        return JsonResponse({"errors": "Detalle vacío"}, status=400)

                    # Guardamos la cabecera de la Compra
                    purchase = form.save(commit=False)
                    purchase.user = request.user
                    purchase.save() # Guardamos la Compra para obtener un ID

                    # Recorremos los detalles
                    for detail in details:
                        prod = Product.objects.get(id=int(detail['id']))
                        
                        # Creamos el detalle de la compra
                        PurchaseDetail.objects.create(
                            purchase=purchase,
                            product=prod,
                            quantify=Decimal(detail['quantify']),
                            cost=Decimal(detail['cost']), # El JS nos enviará el costo
                            subtotal=Decimal(detail['sub']),
                            iva=Decimal(detail['iva'])
                        )
                        
                        # --- ¡AUMENTAMOS EL STOCK! ---
                        # (Lo opuesto a la Venta)
                        prod.stock += Decimal(detail['quantify'])
                        prod.save() 
                        # -----------------------------

                    messages.success(request, "Compra guardada correctamente.")
                    # Devolvemos una respuesta JSON que el JS entenderá
                    return JsonResponse({"url": self.success_url, "msg": "Compra guardada"})
                else:
                    # Si el formulario (proveedor, fecha) no es válido
                    messages.error(request, "Error en los datos de la compra.")
                    return JsonResponse({"errors": form.errors.as_json()}, status=400)
        
        except Product.DoesNotExist as e:
            return JsonResponse({"errors": f"Un producto no existe: {e}"}, status=400)
        except Exception as e:
            # Capturamos cualquier otro error
            return JsonResponse({"errors": str(e)}, status=500)