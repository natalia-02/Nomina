from django.contrib import admin

from core.models import *
admin.site.register(Supplier)
admin.site.register(Customer)
admin.site.register(Brand)
admin.site.register(Category)
admin.site.register(Product)
