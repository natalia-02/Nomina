from django import forms
from core.models import Supplier,Customer,Category, Brand, Product


class SupplierForm(forms.ModelForm):
    class Meta:
        model=Supplier
        fields=['name','ruc','address','phone','state']
        
class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        # Ponemos todos los campos que queremos en el formulario
        fields = [
            'dni',
            'first_name',
            'last_name',
            'address',
            'gender',
            'phone',
            'email',
            'image',
            'state'
        ]

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['description', 'state']
        # widgets = {
        #     'description': forms.TextInput(attrs={'class': 'form-control'}),
        # }

class BrandForm(forms.ModelForm):
    class Meta:
        model = Brand
        fields = ['description', 'state']
        

class ProductForm(forms.ModelForm):
    # Campo para las categorías (Checkbox)
    categories = forms.ModelMultipleChoiceField(
        queryset=Category.objects.filter(state=True),
        widget=forms.CheckboxSelectMultiple,
        required=True,
        label="Categorías"
    )
    
    # Campo para la marca (Select)
    brand = forms.ModelChoiceField(
        queryset=Brand.objects.filter(state=True),
        widget=forms.Select(attrs={'class': 'form-select'}),
        required=True,
        label="Marca"
    )

    # ⬇️ NUEVO: Campo para el Proveedor (Select)
    supplier = forms.ModelChoiceField(
        queryset=Supplier.objects.filter(state=True),
        widget=forms.Select(attrs={'class': 'form-select'}),
        required=True,
        label="Proveedor"
    )
    
    # ⬇️ NUEVO: Campo para la Fecha (Date picker)
    expiration_date = forms.DateTimeField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        required=False,
        label="Fecha de Caducidad"
    )

    class Meta:
        model = Product
        fields = [
            'description',
            'brand',
            'supplier', 
            'categories',
            'line',
            'stock',
            'cost',
            'price',
            'iva',            
            'expiration_date', 
            'image',
            'state'
        ]
        
    # Función para que los campos usen los estilos de Bootstrap
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            
            if field_name not in ['categories', 'brand', 'supplier', 'iva', 'state', 'image', 'expiration_date']:
                field.widget.attrs.update({'class': 'form-control'})