from django.urls import path
from core import views
 
app_name='core' # define un espacio de nombre para la aplicacion
urlpatterns = [
   #path('', views.home,name='home'),
   path('', views.HomeTemplateView.as_view(),name='home'),
   path('supplier_list/', views.SupplierListView.as_view(),name='supplier_list'),
   path('supplier_create/', views.SupplierCreateView.as_view(),name='supplier_create'),
   path('supplier_update/<int:pk>/', views.SupplierUpdateView.as_view(),name='supplier_update'),
   path('supplier_detail/<int:pk>/', views.SupplierDetailView.as_view(),name='supplier_detail'),
   path('supplier_delete/<int:pk>/', views.SupplierDeleteView.as_view(),name='supplier_delete'),
   
   path('customer_list/', views.CustomerListView.as_view(), name='customer_list'),
   path('customer_create/', views.CustomerCreateView.as_view(), name='customer_create'),
   path('customer_update/<int:pk>/', views.CustomerUpdateView.as_view(), name='customer_update'),
   path('customer_detail/<int:pk>/', views.CustomerDetailView.as_view(), name='customer_detail'),
   path('customer_delete/<int:pk>/', views.CustomerDeleteView.as_view(), name='customer_delete'),
   
   path('category_list/', views.CategoryListView.as_view(), name='category_list'),
   path('category_create/', views.CategoryCreateView.as_view(), name='category_create'),
   path('category_update/<int:pk>/', views.CategoryUpdateView.as_view(), name='category_update'),
   path('category_delete/<int:pk>/', views.CategoryDeleteView.as_view(), name='category_delete'),
   
   path('brand_list/', views.BrandListView.as_view(), name='brand_list'),
   path('brand_create/', views.BrandCreateView.as_view(), name='brand_create'),
   path('brand_update/<int:pk>/', views.BrandUpdateView.as_view(), name='brand_update'),
   path('brand_delete/<int:pk>/', views.BrandDeleteView.as_view(), name='brand_delete'),
   
   path('product_list/', views.ProductListView.as_view(), name='product_list'),
   path('product_create/', views.ProductCreateView.as_view(), name='product_create'),
   path('product_update/<int:pk>/', views.ProductUpdateView.as_view(), name='product_update'),
   path('product_delete/<int:pk>/', views.ProductDeleteView.as_view(), name='product_delete'),
]
