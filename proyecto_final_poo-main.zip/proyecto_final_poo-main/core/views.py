from django.shortcuts import render
from django.views.generic import ListView,CreateView,UpdateView,DeleteView, TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from core.mixins import TitleContextMixin
from django.shortcuts import redirect, render
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView, DeleteView,DetailView
from core.forms import SupplierForm, CustomerForm, CategoryForm, BrandForm, ProductForm
from .models import Customer, Supplier, Category, Brand, Product

def home(request):
    data = {
        "title1":"Autor | TeacherCode",
        "title2":"Super Mercado Economico"
    }
   
    return render(request,'home.html',data)

class HomeTemplateView(TitleContextMixin,TemplateView):
   
    template_name = 'home.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["suppliers"] = Supplier.objects.count()
        return context

class SupplierListView(LoginRequiredMixin,TitleContextMixin,ListView): 
    model = Supplier 
    template_name = 'supplier/list.html'  # Nombre del template a usar 
    context_object_name = 'suppliers'     # Nombre del contexto a pasar al template 
    paginate_by = 10   
    title1 = None
    title2 = None                 
    title1 = "Autor | TeacherCode"
    title2 = "Listado de Proveedores mixings"

    def get_queryset(self):
        # Se Puede personalizar el queryset aquí si es necesario
        queryset = super().get_queryset()  # self.model.objects.all()
        query = self.request.GET.get('q','')
        if query:
            queryset = queryset.filter(Q(name__icontains=query) | Q(ruc__icontains=query))
        return queryset
    
   
class SupplierCreateView(LoginRequiredMixin,TitleContextMixin,CreateView):
    model = Supplier
    form_class = SupplierForm
    template_name = "supplier/form.html"
    success_url = reverse_lazy("core:supplier_list")  # Redirigir a la lista de proveedores después de crear uno nuevo
    title1 = '"Proveedores"'
    title2 = 'Crear Nuevo Proveedor VBC'
          
    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class SupplierUpdateView(LoginRequiredMixin,TitleContextMixin,UpdateView):
    model = Supplier
    form_class = SupplierForm
    template_name = "supplier/form.html"
    success_url = reverse_lazy("core:supplier_list")  # Redirigir a la lista de proveedores después de crear uno nuevo
    title1 = '"Proveedores"'
    title2 = 'Editar Proveedor'
   
    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class SupplierDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Supplier
    template_name = "supplier/detail.html"
    context_object_name = "supplier"  # nombre del objeto en el template
    title1 = "Proveedores"
    title2 = "Datos del Proveedor"
    success_url = reverse_lazy("core:supplier_list")

class SupplierDeleteView(LoginRequiredMixin,TitleContextMixin,DeleteView):
    model = Supplier
    template_name = "supplier/delete.html"
    success_url = reverse_lazy("core:supplier_list") 
    title1 = "Eliminar"
    title2 = 'Eliminar Proveedor VBC'
   

class CustomerListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Customer
    template_name = 'customer/list.html'
    context_object_name = 'customers'  # El template itera sobre 'customers'
    paginate_by = 10
    title1 = "Clientes"
    title2 = "Listado de Clientes"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(
                Q(first_name__icontains=query) |
                Q(last_name__icontains=query) |
                Q(dni__icontains=query)
            )
        return queryset

class CustomerCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Customer
    form_class = CustomerForm
    template_name = "customer/form.html"
    success_url = reverse_lazy("core:customer_list")
    title1 = "Clientes"
    title2 = "Crear Nuevo Cliente"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class CustomerUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Customer
    form_class = CustomerForm
    template_name = "customer/form.html"
    success_url = reverse_lazy("core:customer_list")
    title1 = "Clientes"
    title2 = "Editar Cliente"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class CustomerDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Customer
    template_name = "customer/detail.html"
    context_object_name = "customer"
    title1 = "Clientes"
    title2 = "Datos del Cliente"

class CustomerDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Customer
    template_name = "customer/delete.html"
    success_url = reverse_lazy("core:customer_list")
    title1 = "Clientes"
    title2 = "Eliminar Cliente"
    

class CategoryListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Category
    template_name = 'category/list.html'
    context_object_name = 'categories'
    paginate_by = 10
    title1 = "Categorías"
    title2 = "Listado de Categorías"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(description__icontains=query)
        return queryset

class CategoryCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Category
    form_class = CategoryForm
    template_name = "category/form.html"
    success_url = reverse_lazy("core:category_list")
    title1 = "Categorías"
    title2 = "Crear Categoría"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class CategoryUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Category
    form_class = CategoryForm
    template_name = "category/form.html"
    success_url = reverse_lazy("core:category_list")
    title1 = "Categorías"
    title2 = "Editar Categoría"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class CategoryDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Category
    template_name = "category/delete.html"
    success_url = reverse_lazy("core:category_list")
    title1 = "Categorías"
    title2 = "Eliminar Categoría"
    
    # Para que funcione con el template copiado de supplier
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # El template 'delete.html' espera un 'supplier', 
        # le pasamos el objeto 'category' con ese nombre.
        context['supplier'] = self.get_object() 
        return context
    
class BrandListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Brand
    template_name = 'brand/list.html'
    context_object_name = 'brands'
    paginate_by = 10
    title1 = "Marcas"
    title2 = "Listado de Marcas"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(description__icontains=query)
        return queryset

class BrandCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Brand
    form_class = BrandForm
    template_name = "brand/form.html"
    success_url = reverse_lazy("core:brand_list")
    title1 = "Marcas"
    title2 = "Crear Marca"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class BrandUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Brand
    form_class = BrandForm
    template_name = "brand/form.html"
    success_url = reverse_lazy("core:brand_list")
    title1 = "Marcas"
    title2 = "Editar Marca"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class BrandDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Brand
    template_name = "brand/delete.html"
    success_url = reverse_lazy("core:brand_list")
    title1 = "Marcas"
    title2 = "Eliminar Marca"
    
    # Reutilizamos el truco para el template 'delete.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['supplier'] = self.get_object() 
        return context


class ProductListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Product
    template_name = 'product/list.html'
    context_object_name = 'products'
    paginate_by = 10
    title1 = "Productos"
    title2 = "Listado de Productos"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(
                Q(description__icontains=query) | Q(code__icontains=query)
            )
        # Optimizamos la consulta para incluir categorías y marca
        return queryset.select_related('brand').prefetch_related('categories')

class ProductCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Product
    form_class = ProductForm
    template_name = "product/form.html"
    success_url = reverse_lazy("core:product_list")
    title1 = "Productos"
    title2 = "Crear Producto"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class ProductUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Product
    form_class = ProductForm
    template_name = "product/form.html"
    success_url = reverse_lazy("core:product_list")
    title1 = "Productos"
    title2 = "Editar Producto"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class ProductDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Product
    template_name = "product/delete.html"
    success_url = reverse_lazy("core:product_list")
    title1 = "Productos"
    title2 = "Eliminar Producto"
    
    # Reutilizamos el truco para el template 'delete.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # El template 'delete.html' espera 'supplier', le pasamos 'product'
        context['supplier'] = self.get_object() 
        return context