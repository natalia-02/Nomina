// static/js/purchases.js
document.addEventListener('DOMContentLoaded', () => new PurchaseManager());

class PurchaseManager {
  constructor() {
    // --- Referencias DOM ---
    this.d = document;
    this.detailPurchase = []; 

    // Referencias para AÑADIR PRODUCTOS
    this.$product = this.d.getElementById("product");
    this.$cost = this.d.getElementById("cost");
    this.$quantify = this.d.getElementById("quantify");
    this.$btnAdd = this.d.getElementById("btnAdd");
    
    // Referencias al FORM y TABLA
    this.$form = this.d.getElementById("frmPurchase");
    this.$detailBody = this.d.getElementById("detalle_purchase");

    // Referencias a los TOTALES
    this.subtotalInput = this.d.getElementById("id_subtotal");
    this.ivaInput = this.d.getElementById("id_iva");
    this.totalInput = this.d.getElementById("id_total");

    // --- Eventos ---
    this.initEvents();
  }

  // ---------------- Eventos ----------------
  initEvents() {
    // (No necesitamos 'onProductChange' si el costo es manual)
    this.$btnAdd.addEventListener('click', () => this.addProduct());
    this.$detailBody.addEventListener('click', e => this.removeProduct(e));
    this.$form.addEventListener('submit', e => this.submitForm(e));
  }

  // ---------------- Métodos principales ----------------
  addProduct() {
    const selected = this.$product.options[this.$product.selectedIndex];
    if (!selected.value) return alert("Seleccione un producto");

    const stock = parseInt(selected.dataset.stock || 0);
    const quantify = parseInt(this.$quantify.value);
    
    // 3. LEEMOS EL COSTO
    const cost = parseFloat(this.$cost.value);

    if (quantify <= 0) {
      return alert("La cantidad debe ser mayor a cero.");
    }
    if (cost <= 0) {
      return alert("El costo debe ser mayor a cero.");
    }

    const id = parseInt(selected.value);
    const description = selected.text;
    const iva = parseFloat(selected.dataset.iva); // Leemos el % de IVA
    
    // 4. CALCULAMOS EN BASE AL COSTO
    this.calculateProduct(id, description, iva, cost, quantify);
  }

  calculateProduct(id, description, iva, cost, quantify) {
    // (Esta lógica es idéntica a la de tu docente en sales.js)
    const existing = this.detailPurchase.find(p => p.id === id);
    if (existing && !confirm(`"${description}" ya está agregado. ¿Desea actualizar la cantidad?`)) return;

    if (existing) {
      quantify += existing.quantify;
      this.detailPurchase = this.detailPurchase.filter(p => p.id !== id);
    }

    // Calculamos el IVA (asumiendo que el IVA es 15%)
    // Tu modelo Product tiene 'iva' (0, 5, 15). Lo usamos.
    const ivaValue = iva > 0 ? (cost * quantify * (iva / 100)) : 0;
    
    // 5. CAMBIAMOS 'price' POR 'cost'
    let sub = cost * quantify + ivaValue;
    this.detailPurchase.push({ id, description, cost, quantify, iva: ivaValue, sub });
    
    this.renderDetail();
    this.updateTotals();
  }

  renderDetail() {
    // 6. ADAPTAMOS LA TABLA
    this.$detailBody.innerHTML = this.detailPurchase.map(prod => `
      <tr>
        <td>${prod.id}</td>
        <td>${prod.description}</td>
        <td>${prod.cost.toFixed(2)}</td> <td>${prod.quantify}</td>
        <td>${prod.iva.toFixed(2)}</td>
        <td>${prod.sub.toFixed(2)}</td>
        <td class="text-center">
          <button class="text-danger" data-id="${prod.id}" rel="rel-delete">
            <i class="fa-solid fa-trash"></i>
          </button>
        </td>
      </tr>`).join('');
  }

  removeProduct(e) {
    const btn = e.target.closest('button[rel=rel-delete]');
    if (!btn) return;
    const id = parseInt(btn.dataset.id);
    this.detailPurchase = this.detailPurchase.filter(p => p.id !== id);
    this.renderDetail();
    this.updateTotals();
  }

  updateTotals() {
    // (Idéntico a sales.js)
    const totals = this.detailPurchase.reduce((acc, p) => {
      acc.iva += p.iva;
      acc.sub += p.sub;
      return acc;
    }, { iva: 0, sub: 0 });

    this.subtotalInput.value = (totals.sub - totals.iva).toFixed(2);
    this.ivaInput.value = totals.iva.toFixed(2);
    this.totalInput.value = totals.sub.toFixed(2);
  }

  async submitForm(e) {
    e.preventDefault();
    if (parseFloat(this.totalInput.value) <= 0) {
      return alert("Debe agregar productos antes de guardar la compra.");
    }
    // 'save_url' y 'purchase_list_url' son las variables globales del template
    await this.savePurchase(save_url, purchase_list_url);
  }

  async savePurchase(urlPost, urlSuccess) {
    
    // 1. Usamos el método de tu docente (simple y directo)
    const formData = new FormData(this.$form);
    
    // 2. Añadimos el detalle
    formData.append("detail", JSON.stringify(this.detailPurchase)); 

    const csrf = this.d.querySelector('[name=csrfmiddlewaretoken]').value;

    try {
      // 3. ENVIAMOS EL FETCH (Esta parte no cambia)
      const res = await fetch(urlPost, {
        method: 'POST',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRFToken': csrf, 
        },
        body: formData // Enviamos el FormData simple
      });

      const result = await res.json(); 

      if (!res.ok) {
         throw new Error(`Error del servidor: ${result.errors || JSON.stringify(result)}`); 
      }
      
      // ¡ÉXITO!
      alert(result.msg || "Compra guardada correctamente");
      window.location.href = urlSuccess; 

    } catch (err) {
      console.error("Error en guardado:", err);
      alert("Error al grabar la compra: " + err.message); 
    }
  }
  // ⬆️ FIN DEL REEMPLAZO DE savePurchase ⬆️

}